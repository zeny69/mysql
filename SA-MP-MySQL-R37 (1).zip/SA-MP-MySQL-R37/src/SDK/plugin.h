//----------------------------------------------------------
//
//   SA:MP Multiplayer Modification For GTA:SA
//   Copyright 2004-2006 SA:MP Team
//
//----------------------------------------------------------

#include <SDK/plugincommon.h>
#include <SDK/amx/amx.h>

//----------------------------------------------------------
// EOF
